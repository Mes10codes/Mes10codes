pullTotalSupply()

if (performance.navigation.type == performance.navigation.TYPE_RELOAD) {
    pullTotalSupply()
}

function sleep(milli) {
    const date = Date.now()
    let currentDate = null;

    do {
        currentDate = Date.now()
    } while ( currentDate - date < milli);
}

function updateWebsite(totalSupply){
    document.getElementById("totalSupply").innerHTML = totalSupply
}

function pullTotalSupply() {
    fetch('https://api.trippieheadz.io/get/stock').then(function (response) {
        return response.json();
    }).then(function (data) {
        console.log(data.result);
        updateWebsite(data.result)
    }).catch(function (err){
        console.warn('Something went wrong!', err);
    })


}