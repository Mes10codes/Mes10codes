if (typeof window.ethereum !== "undefined") {
    console.log('Metamask is Installed.');
} else {

    console.log('Install Metamask.');
}


const connect_btn = document.getElementById('connect-wallet');
connect_btn.addEventListener("click", getMetaMaskAccount);

async function getMetaMaskAccount() {

    const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
    const account = accounts[0]
    
    connect_btn.innerHTML = account.substring(0,4) + "..." + account.substring(37,42);

    const balance = await ethereum
    .request({
        method: 'eth_getBalance',
        params: [account, "latest"]
    });

    const read = parseInt(balance)/ 10**18;


}